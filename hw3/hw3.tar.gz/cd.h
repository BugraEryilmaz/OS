#pragma once
#include "fat32helper.h"

void changeDir(std::wstring dir);