#pragma once
#include "fat32helper.h"

void printFile(FatFileEntry *file, std::wstring fileName);